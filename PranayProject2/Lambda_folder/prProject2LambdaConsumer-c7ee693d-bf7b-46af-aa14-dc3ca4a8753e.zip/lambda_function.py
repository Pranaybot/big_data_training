import json
import os
import boto3
from datetime import datetime, timedelta

def lambda_handler(event, context):
    # Initialize DynamoDB client
    dynamodb = boto3.resource('dynamodb')
    table_name = os.environ['DYNAMODB_TABLE_NAME']
    table = dynamodb.Table(table_name)

    # Process each record from Kinesis
    try:
        for record in event['Records']:
            # Decode Kinesis data from base64 and parse JSON
            review = json.loads(record['kinesis']['data'])

            # Prepare item to insert into DynamoDB
            current_timestamp = datetime.now().isoformat()
            time_lag = (datetime.now() - datetime.fromisoformat(review['review_timestamp'])).total_seconds()  # Calculate time lag in seconds

            item = {
                'product_id': review['product_id'],
                'user_id': review['user_id'],
                'date_id': review['date_id'],
                'product_name': review.get('product_name', 'N/A'),  # Default value if not provided
                'product_brand': review.get('product_brand', 'N/A'),  # Default value if not provided
                'product_price': review.get('product_price', 0.0),  # Default value if not provided
                'user_name': review.get('user_name', 'N/A'),  # Default value if not provided
                'user_city': review.get('user_city', 'N/A'),  # Default value if not provided
                'user_state': review.get('user_state', 'N/A'),  # Default value if not provided
                'rating': review['rating'],
                'review_text': review['review_text'],
                'review_timestamp': review['review_timestamp'],
                'current_timestamp': current_timestamp,
                'time_lag': time_lag  # Time lag in seconds
            }

            # Insert item into DynamoDB
            table.put_item(Item=item)

    except Exception as e:
        print(f"Error processing records: {e}")
        return {
            'statusCode': 500,
            'body': json.dumps(f"Error processing records: {e}")
        }

    return {
        'statusCode': 200,
        'body': json.dumps('Consumed and inserted messages successfully!')
    }
