import json
import os
import time
import random
from datetime import datetime
import boto3

# Predefined arrays of values
product_names = ["Smartphone", "Headphones", "Smartwatch", "Tablet", "Laptop"]
product_brands = ["BrandA", "BrandB", "BrandC", "BrandD"]
# Define the minimum and maximum price range
min_price = 199.99
max_price = 599.99
user_names = ["Alice", "Bob", "Charlie", "David", "Eve"]
user_cities = ["Seattle", "New York", "Los Angeles", "Chicago", "Austin"]
user_states = ["WA", "NY", "CA", "IL", "TX"]

# Define a review message structure
def create_review_message():
    """Generates a review message with random data."""
    product_string = random.randint(1, 1000)  # Simulating product_id as a random integer
    user_string = random.randint(1, 500)       # Simulating user_id as a random integer
    date_string = int(datetime.now().strftime("%Y%m%d"))
    
    # Create the review message using the predefined arrays
    data = {
        "product_id": product_string,
        "user_id": user_string,
        "date_id": date_string,
        "product_name": random.choice(product_names),
        "product_brand": random.choice(product_brands),
        "product_price": round(random.uniform(min_price, max_price), 2),  # Generate a random price
        "user_name": random.choice(user_names),
        "user_city": random.choice(user_cities),
        "user_state": random.choice(user_states),
        "rating": random.randint(1, 5),
        "review_text": f"Sample review text {random.randint(1, 1000)}",
        "review_timestamp": datetime.now().isoformat()
    }
    
    return data

def lambda_handler(event, context):
    """Lambda function handler to write review messages to a Kinesis stream."""
    # Initialize Kinesis client
    kinesis_client = boto3.client('kinesis')

    # Load environment variables
    kinesis_stream_name = os.environ['KINESIS_STREAM_NAME']
    partition_key = os.environ.get('KINESIS_PARTITION_KEY', 'product_id')

    try:
        # Generate 50 review messages
        for _ in range(50):
            message = create_review_message()
            message_data = json.dumps(message)
            
            # Send the message to the Kinesis stream
            kinesis_client.put_record(
                StreamName=kinesis_stream_name,
                Data=message_data,
                PartitionKey=str(message[partition_key])
            )
            
            time.sleep(random.uniform(0.1, 0.5))  # Simulate a delay between messages

        return {
            'statusCode': 200,
            'body': json.dumps(f'Produced messages successfully to Kinesis stream: {kinesis_stream_name}')
        }

    except Exception as e:
        return {
            'statusCode': 500,
            'body': json.dumps(f'Error producing messages: {str(e)}')
        }
