import os
import boto3
import psycopg2
import pandas as pd
from io import StringIO
import json
from datetime import datetime
from botocore.exceptions import ClientError

def fetch_data_from_postgresql():
    try:
        # Connect to PostgreSQL using environment variables
        conn = psycopg2.connect(
            host=os.environ['JDBC_HOSTNAME'],
            port=os.environ['JDBC_PORT'],
            database=os.environ['JDBC_DATABASE'],
            user=os.environ['JDBC_USERNAME'],
            password=os.environ['JDBC_PASSWORD']
        )
        print("Successfully connected to PostgreSQL.")

        # Load data into a DataFrame
        query = "SELECT * FROM amazon_reviews"
        df = pd.read_sql(query, conn)

        # Convert date and timestamp columns
        df['review_date'] = pd.to_datetime(df['review_date']).dt.date
        df['review_timestamp'] = pd.to_datetime(df['review_timestamp'])

        # Close the connection
        conn.close()
        print("Data fetched successfully.")
        return df

    except psycopg2.Error as e:
        print(json.dumps({
            'error': f"Database connection failed: {str(e)}"
        }))
        raise

def upload_data_to_s3(df):
    try:
        # Convert DataFrame to CSV in memory
        csv_buffer = StringIO()
        df.to_csv(csv_buffer, index=False)

        # S3 upload parameters
        s3_bucket = os.environ['S3_BUCKET']
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        s3_key = f"amazon_reviews_{timestamp}.csv"
        s3 = boto3.client('s3')

        # Upload the file to S3
        s3.put_object(
            Bucket=s3_bucket,
            Key=s3_key,
            Body=csv_buffer.getvalue()
        )
        print(json.dumps({
            'message': 'File uploaded successfully',
            'bucket': s3_bucket,
            'key': s3_key
        }))

    except ClientError as e:
        print(json.dumps({
            'error': f"An error occurred: {e.response['Error']['Message']}"
        }))
        raise

def lambda_handler(event, context):
    try:
        # Fetch data from PostgreSQL
        df = fetch_data_from_postgresql()

        # Upload data to S3
        upload_data_to_s3(df)

        return {
            'statusCode': 200,
            'body': json.dumps("Data from PostgreSQL has been successfully loaded to S3.")
        }

    except Exception as e:
        return {
            'statusCode': 500,
            'body': json.dumps(f"Error: {str(e)}")
        }
